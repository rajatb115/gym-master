from django.apps import AppConfig


class EntrepreneurshipConfig(AppConfig):
    name = 'entrepreneurship'
