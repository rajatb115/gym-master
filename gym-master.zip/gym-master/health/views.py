from health.models import Blog,Category
from django.shortcuts import render_to_response, get_object_or_404

def health(request):
    return render_to_response('health/index.html', {
        'categories': Category.objects.all(),
        'posts': Blog.objects.all().order_by("-posted")[:5]
    })

def health_post(request, slug):
    return render_to_response('health/veiw_post.html', {
        'post': get_object_or_404(Blog, slug=slug)
    })

def health_category(request, slug):
    category = get_object_or_404(Category, slug=slug)
    return render_to_response('health/view_category.html', {
        'category': category,
        'posts': Blog.objects.filter(category=category).order_by("-posted")[:5]
    })