from django.apps import AppConfig


class PoliticsConfig(AppConfig):
    name = 'politics'
